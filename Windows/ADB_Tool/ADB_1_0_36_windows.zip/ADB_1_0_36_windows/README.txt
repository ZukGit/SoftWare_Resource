#Mon Jul 11 15:58:51 MSK 2016
Pkg.Revision=24

Android Debug Bridge version 1.0.36
Revision fd9e4d07b0f5-android