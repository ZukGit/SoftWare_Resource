The go plugin is deprecated. Use the [golang plugin](https://github.com/robbyrussell/oh-my-zsh/tree/master/plugins/golang) instead.
